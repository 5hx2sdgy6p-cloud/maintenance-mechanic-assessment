import React, { memo } from 'react';

const QuestionCard = ({ question, selectedAnswer, onAnswerSelect, questionNumber, totalQuestions, showDomain = true }) => {
  if (!question) return null;

  const isMultipleChoice = question.type === 'multiple-choice';
  const isTrueFalse = question.type === 'true-false';

  const handleAnswerClick = (answer) => {
    if (onAnswerSelect) {
      onAnswerSelect(answer);
    }
  };

  const isSelected = (option) => {
    return selectedAnswer === option;
  };

  const renderMultipleChoice = () => {
    if (!question.options) return null;
    return question.options.map((option, index) => (
      <button
        key={index}
        onClick={() => handleAnswerClick(index)}
        style={{
          padding: '1.25rem',
          background: isSelected(index) ? 'rgba(79, 195, 247, 0.2)' : 'rgba(255, 255, 255, 0.05)',
          border: isSelected(index) ? '2px solid #4fc3f7' : '1px solid rgba(255, 255, 255, 0.1)',
          borderRadius: '6px',
          color: '#e8eaed',
          fontSize: '1rem',
          cursor: 'pointer',
          textAlign: 'left',
          transition: 'all 0.2s ease',
          display: 'flex',
          alignItems: 'center',
          gap: '1rem',
          width: '100%',
          marginBottom: '1rem'
        }}
      >
        <div style={{
          width: '24px',
          height: '24px',
          borderRadius: '50%',
          border: '2px solid currentColor',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0
        }}>
          {isSelected(index) ? (
            <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#4fc3f7' }} />
          ) : (
            String.fromCharCode(65 + index)
          )}
        </div>
        <span>{option}</span>
      </button>
    ));
  };

  const renderTrueFalse = () => {
    return [true, false].map((option) => (
      <button
        key={option.toString()}
        onClick={() => handleAnswerClick(option)}
        style={{
          padding: '1.25rem',
          background: isSelected(option) ? 'rgba(79, 195, 247, 0.2)' : 'rgba(255, 255, 255, 0.05)',
          border: isSelected(option) ? '2px solid #4fc3f7' : '1px solid rgba(255, 255, 255, 0.1)',
          borderRadius: '6px',
          color: '#e8eaed',
          fontSize: '1.1rem',
          cursor: 'pointer',
          textAlign: 'left',
          transition: 'all 0.2s ease',
          display: 'flex',
          alignItems: 'center',
          gap: '1rem',
          width: '100%',
          marginBottom: '1rem'
        }}
      >
        <div style={{
          width: '24px',
          height: '24px',
          borderRadius: '50%',
          border: '2px solid currentColor',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0
        }}>
          {isSelected(option) && (
            <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#4fc3f7' }} />
          )}
        </div>
        <span>{option ? 'TRUE' : 'FALSE'}</span>
      </button>
    ));
  };

  return (
    <div style={{
      background: 'rgba(255, 255, 255, 0.05)',
      backdropFilter: 'blur(10px)',
      borderRadius: '0 0 8px 8px',
      padding: '2.5rem',
      border: '1px solid rgba(255, 255, 255, 0.1)',
      borderTop: 'none',
      minHeight: '400px',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {showDomain && question.domain && (
        <div style={{ marginBottom: '1.5rem' }}>
          <span style={{
            padding: '0.4rem 0.8rem',
            background: 'rgba(79, 195, 247, 0.2)',
            border: '1px solid #4fc3f7',
            borderRadius: '4px',
            fontSize: '0.75rem',
            fontWeight: '700',
            textTransform: 'uppercase',
            letterSpacing: '1px',
            color: '#4fc3f7'
          }}>
            {question.domain}
          </span>
        </div>
      )}

      <h2 style={{
        fontSize: '1.4rem',
        fontWeight: '400',
        marginBottom: '2rem',
        color: '#e8eaed',
        lineHeight: '1.6',
        flex: '0 0 auto'
      }}>
        {question.question}
      </h2>

      <div style={{ flex: '1 1 auto', display: 'flex', flexDirection: 'column' }}>
        {isMultipleChoice && renderMultipleChoice()}
        {isTrueFalse && renderTrueFalse()}
      </div>
    </div>
  );
};

export default memo(QuestionCard);