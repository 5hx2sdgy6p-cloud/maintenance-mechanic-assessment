import { QUESTION_BANK, STORAGE_KEYS, ASSESSMENT_LEVELS } from '../constants/assessmentConstants';
import { calculatePercentage, getCurrentDateTime, generateId, safeLocalStorageGet, safeLocalStorageSet } from '../utils/helpers';

// Shuffle array helper
const shuffleArray = (array) => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

export const generateQuestions = (assessmentLevel = 'level4') => {
  const levelConfig = Object.values(ASSESSMENT_LEVELS).find(l => l.id === assessmentLevel) || ASSESSMENT_LEVELS.LEVEL_4;
  const allQuestions = [];
  
  Object.keys(QUESTION_BANK).forEach(category => {
    const categoryQuestions = [];
    
    Object.keys(QUESTION_BANK[category]).forEach(level => {
      // Only include questions from the allowed skill levels
      if (levelConfig.skillLevels.includes(level)) {
        QUESTION_BANK[category][level].forEach(question => {
          categoryQuestions.push({ ...question, level, category });
        });
      }
    });
    
    // Shuffle questions within this category
    const shuffled = shuffleArray(categoryQuestions);
    
    // If questionsPerDomain is set, limit the number; otherwise take all
    if (levelConfig.questionsPerDomain) {
      allQuestions.push(...shuffled.slice(0, levelConfig.questionsPerDomain));
    } else {
      allQuestions.push(...shuffled);
    }
  });
  
  // Shuffle all questions together for final randomization
  return shuffleArray(allQuestions);
};

export const isAnswerCorrect = (question, userAnswer) => {
  if (question.type === 'true-false') {
    return userAnswer === question.correct;
  }
  return userAnswer === question.correct;
};

export const calculateResults = (questions, answers) => {
  const scoreByDomain = {};
  const scoreByLevel = { entry: { correct: 0, total: 0 }, intermediate: { correct: 0, total: 0 }, advanced: { correct: 0, total: 0 } };
  
  questions.forEach(question => {
    const userAnswer = answers[question.id];
    const correct = isAnswerCorrect(question, userAnswer);
    
    if (!scoreByDomain[question.domain]) {
      scoreByDomain[question.domain] = { correct: 0, total: 0 };
    }
    scoreByDomain[question.domain].total++;
    if (correct) scoreByDomain[question.domain].correct++;
    
    if (scoreByLevel[question.level]) {
      scoreByLevel[question.level].total++;
      if (correct) scoreByLevel[question.level].correct++;
    }
  });
  
  const totalCorrect = Object.values(scoreByDomain).reduce((sum, score) => sum + score.correct, 0);
  const totalQuestions = questions.length;
  const overallScore = calculatePercentage(totalCorrect, totalQuestions);
  
  return {
    overallScore,
    totalCorrect,
    totalQuestions,
    scoreByDomain,
    scoreByLevel,
    recommendations: [],
    weakAreas: [],
  };
};

export const saveCompletedAssessment = (userData, results, questions, answers) => {
  try {
    const existing = safeLocalStorageGet(STORAGE_KEYS.COMPLETED_ASSESSMENTS);
    const assessmentRecord = {
      id: generateId(),
      userData,
      results,
      questions: questions || [],
      answers: answers || {},
      completedDate: getCurrentDateTime(),
    };
    existing.push(assessmentRecord);
    return safeLocalStorageSet(STORAGE_KEYS.COMPLETED_ASSESSMENTS, existing);
  } catch (error) {
    console.error('Error saving completed assessment:', error);
    return false;
  }
};

export const loadSavedAssessments = () => {
  return safeLocalStorageGet(STORAGE_KEYS.SAVED_ASSESSMENTS);
};

export const loadCompletedAssessments = () => {
  return safeLocalStorageGet(STORAGE_KEYS.COMPLETED_ASSESSMENTS);
};
