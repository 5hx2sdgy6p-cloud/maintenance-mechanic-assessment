import { useState, useEffect, useCallback } from 'react';
import { loadSavedAssessments, loadCompletedAssessments } from '../services/assessmentService';
import { safeLocalStorageSet } from '../utils/helpers';
import { STORAGE_KEYS } from '../constants/assessmentConstants';

export const useSavedAssessments = () => {
  const [savedAssessments, setSavedAssessments] = useState([]);
  
  const loadAssessments = useCallback(() => {
    const assessments = loadSavedAssessments();
    setSavedAssessments(assessments);
  }, []);
  
  useEffect(() => {
    loadAssessments();
  }, [loadAssessments]);
  
  const saveAssessment = useCallback((assessmentData) => {
    const existing = loadSavedAssessments();
    const filtered = existing.filter(a => a.userData.employeeId !== assessmentData.userData.employeeId);
    filtered.push({ ...assessmentData, id: Date.now(), savedDate: new Date().toLocaleString() });
    safeLocalStorageSet(STORAGE_KEYS.SAVED_ASSESSMENTS, filtered);
    loadAssessments();
    return true;
  }, [loadAssessments]);
  
  const deleteAssessment = useCallback((assessmentId) => {
    const existing = loadSavedAssessments();
    const filtered = existing.filter(a => a.id !== assessmentId);
    safeLocalStorageSet(STORAGE_KEYS.SAVED_ASSESSMENTS, filtered);
    loadAssessments();
    return true;
  }, [loadAssessments]);
  
  return { savedAssessments, saveAssessment, deleteAssessment, reload: loadAssessments };
};

export const useCompletedAssessments = () => {
  const [completedAssessments, setCompletedAssessments] = useState([]);
  
  const loadAssessments = useCallback(() => {
    const assessments = loadCompletedAssessments();
    setCompletedAssessments(assessments);
  }, []);
  
  useEffect(() => {
    loadAssessments();
  }, [loadAssessments]);
  
  const deleteAssessment = useCallback((assessmentId) => {
    const existing = loadCompletedAssessments();
    const filtered = existing.filter(a => a.id !== assessmentId);
    safeLocalStorageSet(STORAGE_KEYS.COMPLETED_ASSESSMENTS, filtered);
    loadAssessments();
    return true;
  }, [loadAssessments]);
  
  return { completedAssessments, deleteAssessment, reload: loadAssessments };
};